package src.security;

public class OauthConsts {

    public final static String CRM_NAME = "MY_CRM";

    public final static String DEFAULT_CLIENT_ID = "DEFAULT_CLIENT";

    public final static String TRUNCATED_CLIENT_ID = "TRUNCATED_CLIENT";

    public final static String DEFAULT_CLIENT_SECRET = "secret";

    public final static String TRUNCATED_CLIENT_SECRET = "secret";
}
