package src.security;

public enum ClientScopes {
    /*Obtain/revoke token*/
    TRUSTED_CLIENT,

    /*CRUD on secured user info*/
    USER_INFO,
}
